﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milestone_2_Progress
{
    public class Beacons
    {
        public int Free { get; set; }
        public int Total {get; set;}
        public Beacon[] data;
    }
}
