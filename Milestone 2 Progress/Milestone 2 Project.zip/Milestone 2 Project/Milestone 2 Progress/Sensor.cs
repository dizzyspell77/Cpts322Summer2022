﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milestone_2_Progress
{
    class Sensor
    {
        int PrintPosition;

        int Id { get; set; }

    }
}
